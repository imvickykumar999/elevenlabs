## Steps to run:

```bash
python3 -m venv venv

# Ubuntu
source venv/bin/activate

# Windows
venv\Scripts\activate

pip install -r requirements.txt

```
