import os
import time
from elevenlabs import Voice, VoiceSettings, save
from elevenlabs.client import ElevenLabs

from dotenv import load_dotenv
load_dotenv()

# https://elevenlabs.io/app/settings/api-keys
API_KEY = os.getenv("XI_API_KEY")  # Replace with your API key

# Initialize ElevenLabs client
client = ElevenLabs(api_key=API_KEY)

# Function to ensure directory exists
def ensure_directory_exists(directory):
    """Creates the directory if it does not exist."""
    if not os.path.exists(directory):
        os.makedirs(directory)
        print(f"Created directory: {directory}")

# Function to read names from a file or return a fallback list
def file_to_list(filename):
    """Reads names from a file and returns them as a list. Uses fallback names if file is missing."""
    if not os.path.exists(filename):
        print(f"Warning: The file {filename} was not found. Using fallback names.")
        return ["Vicky Kumar"]  # Fallback names

    with open(filename, 'r', encoding="utf-8") as file:
        return [line.strip() for line in file if line.strip()]

# Ensure "names/" directory exists for storing generated files
ensure_directory_exists("names")
filename = "names/usernames.txt"

# Read names from file (or use fallback)
texts = file_to_list(filename)[0:5]  # Limiting to first 5 for testing
print("Names to be processed:", texts)

# Start time tracking
t1 = time.time()

# Generate voice messages for each name
for index, text in enumerate(texts):
    try:
        audio = client.generate(
            text=f"नमस्ते {text} जी",
            voice=Voice(
                voice_id="MF4J4IDTRo0AxOO4dpFR",  # Change if needed
                settings=VoiceSettings(
                    stability=0.71, 
                    similarity_boost=1.0, 
                    style=0.0, 
                    use_speaker_boost=True
                )
            ),
            model="eleven_multilingual_v2"
        )

        # Save audio file in "names/" directory
        filename = f"names/{index}-{text}.mp3"
        save(audio, filename)
        print(f"✅ Saved: {filename}")

    except Exception as e:
        print(f"❌ Error processing {text}: {e}")

# End time tracking
t2 = time.time()
print(f"⏱️ Time taken: {t2 - t1:.2f} seconds")
