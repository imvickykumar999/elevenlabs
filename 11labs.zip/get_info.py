import requests
import os
from pprint import pprint

from dotenv import load_dotenv
load_dotenv()

# https://elevenlabs.io/app/settings/api-keys
API_KEY = os.getenv("XI_API_KEY")
url = "https://api.elevenlabs.io/v1/models"

headers = {
    "Accept": "application/json",
    "xi-api-key": API_KEY,
    "Content-Type": "application/json"
}

response = requests.get(url, 
  headers=headers
)

if response.status_code == 200:
    data = response.json()
    pprint(data)
else:
    print(f"Error: {response.status_code} - {response.text}")
